Controls available are:

A : Walk left
S : Walk back
W : Walk forward
D : Walk right
X : Rotate shape about X axis
Y : Rotate shape about Y axis
Z : Rotate shape about Z axis
+ : Scale up shape
- : Scale down shape
J : Rotate camera to the left
L : Rotate camera to the right
U : Move contour plane up
I : Move contour plane down
N : Increase the iso value
M : Decrease the iso value

For convenience I have attached the exe

Link to video: https://photos.app.goo.gl/zEYMdamfck8ZV9q1A